from utilities.utilities import *

def cleaning_path(elt, sep):
    """
    transforming list information to string
    with the sep given
    INPUTS
    elt : the list containing strings
    sep : the separator to join elements in the list
    OUTPUTS
    string with elements of the list joined with sep
    """
    return f"{sep}".join(elt).strip()


def retrieving_match(html_list_2):
    """
    taking the html pieces containing the html key
    and extracting elements
    INPUTS
    html_list_2: dict with key: stage and html piece
                                containing information about the match
    OUTPUTS
    list_matches : dataframe with the matches

    """
    # match_information = dict()
    liste_matches = []
    for round_ in html_list_2.keys():
        for match in html_list_2[round_]:
            match_information = dict()
            match_information["statut"] = cleaning_path(
                match.xpath(".//div[contains(@class, 'js-match-status')]/text()"), "")
            match_information["duration"] = cleaning_path(
                match.xpath(".//span[contains(@class, 'js-match-time')]/span[@class='tennis-match__time']/text()"), "")
            match_information["stage"] = cleaning_path(
                match.xpath(".//div[@class='tennis-match__round js-match-round']/text()"), "")
            match_information["url_match_stats"] = "https://wtatennis.com" + cleaning_path(
                match.xpath(".//a[@class='tennis-match__match-link']/@href"), "")
            match_lines = match.xpath(".//tr[@class='match-table__row']")
            for player in match_lines:
                index_p = match_lines.index(player) + 1
                match_information[f"player_{index_p}_name"] = \
                player.xpath(".//span[@class='match-table__player-fname']/text()")[0] + \
                player.xpath(".//span[@class='match-table__player-lname']/text()")[0]
                player_sets = player.xpath(".//td[contains(@class, 'match-table__score-cell')]")
                for set_ in player_sets:
                    index_s = player_sets.index(set_) + 1
                    match_information[f"player_{index_p}_set_{index_s}"] = cleaning_path(set_.text, "")
                    if len(set_.xpath(".//sup[@class='match-table__tie-break']")):
                        tie_break_score = set_.xpath(".//sup[@class='match-table__tie-break']")[0].text
                        match_information[f"player_{index_p}_set_{index_s}_tiebreak"] = tie_break_score
                    else:
                        match_information[f"player_{index_p}_set_{index_s}_tiebreak"] = ""
            match_information['day'] = round_

            liste_matches.append(match_information)

    return pd.DataFrame(liste_matches)

def retrieve_matches_html_robust(tournament_url):
    """
    retrieve all the html elements for
    the differents matches of the specific
    tournament
    INPUTS
    -tournament_url : url toward the match
    OUTPUT
    -html_list : list of html elements containing each matches infos
    """

    def retrieve_stage_html(step):
        """
        for a given step Qualifying, Singles,
        retrieve all the matches informatio
        INPUTS
        -step : ['Qualifying', 'Singles', 'Doubles']
        RETURN
        dict: the html corresponding to the stage
        """
        driver = webdriver.Firefox(options=options, executable_path=executable_path)
        driver.get(tournament_url)
        time.sleep(2)

        html_list = defaultdict(list)
        tree_list = []
        # Find the cookie notice button and click on it to dismiss the notice
        cookie_notice = driver.find_element(By.CLASS_NAME, 'cookie-notice__button')
        if cookie_notice.is_displayed():
            cookie_notice.click()

        # Find the "Qualifying" tab and click on it
        try:
            stage_tab = driver.find_element(By.XPATH, f"//li[@role='tab' and text()='{step}']")
            stage_tab.click()
            time.sleep(1)
            # Find the day buttons and loop through them
            buttons = driver.find_elements(By.CSS_SELECTOR, 'button.day-navigation__button.js-day-button:not(.is-empty)')
            for button in buttons:
                button.click()
                print('Clicked button for', button.get_attribute('title'))
                time.sleep(2)

                # Get the HTML and add it to the list
                tree = html.fromstring(driver.page_source)
                tree_list.append(tree)
                to_store = tree.xpath(
                    "//div[contains(@class, 'tournament-scores')]//div[contains(@class, 'js-scores-day is-active')]//li[@class='tournament-scores__item']"
                    )

                html_list[f"{step}-{button.get_attribute('title')}"] = to_store
        except Exception as e:
            print(f"impossible de retrouver des matchs pour cette section {step}")

        driver.close()           

        return html_list
        
    tree_list = []
    steps = ["Qualifying", "Singles"]

    try:
        qualifying_html = retrieve_stage_html("Qualifying")
    except Exception as e:
        print(f"impossible to retireves matches for stage: Qualifying")
    
    try:
        qualifying_singles = retrieve_stage_html("Singles")
    except Exception as e:
        print(f"impossible to retrieve matches for stage: Singles")

    html_list = {**qualifying_html, **qualifying_singles}

    tournament_match = retrieving_match(html_list)
    tournament_match["tournament_url"] = tournament_url

    return retrieving_match(html_list)
    