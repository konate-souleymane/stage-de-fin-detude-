import re
from datetime import datetime
from dateutil.relativedelta import relativedelta
import time
from utilities.utilities import *


def players_info(entetes, *args):
    """
    informations personnelles sur les joueuses
    INPUTS
    ==============================
    entetes : names of the information concerning the player [h2h against oponent, age, laterality]
    *args : the information in question
    =============================
    OUTPUTS
    stats : stats for the match

    """
    assert len(set([len(arg) for arg in args])) == 1, "taille differente des donnees d'entrée pour les joueuses"
    stats = dict()

    entetes_recreated = [[f"{entete}_player_1", f"{entete}_player_2"] for entete in entetes]
    entetes_recreated = [elt for sublist in entetes_recreated for elt in sublist]
    # print("hey",entetes_recreated)
    list_args = [elt for arg in args for elt in arg]

    stats = {f"{entete}": p1_datum for (entete, p1_datum) in zip(entetes_recreated, list_args)}
    return stats


def extract_height(height):

    #print(f"height {height}")
    #'r'(\d+\.\d+)\s*m'
    #re.search(r'(\d+\.\d+)', height)
    #data = re.findall(r'\d+\.\d+', height)
    if height=="N/A":
        return ""
    else:
        return re.findall(r'\d+\.\d+', height)[0]
        


def birthday(date_anniv):
    today = datetime.now()
    age_years = relativedelta(today, datetime.strptime(date_anniv, "%d %b %Y")).years
    age_months = relativedelta(today, datetime.strptime(date_anniv, "%d %b %Y")).months
    return round(age_years + age_months / 12, 2)


# get entete of the data

# categorie
def match_statistics(index, entetes, player_1_data, player_2_data):
    """
    compiler les donnees des joueurs suivant les categories de
    statistiques.
    INPUTS
    ==============================
    index = [match, set1, set2, set3] : categorie de stats
    entetes : categorie de stats
    player_1_data : donnees pour le joueur 1
    player_2_data : donnees pour le joueur 2
    =============================
    OUTPUTS
    stats : stats for the match

    """
    #print(f"entetes: {entetes}")
    #print(f"player1: {player_1_data}")
    #print(f"player2: {player_2_data}")
    assert len(entetes) == len(player_1_data) and len(player_1_data) == len(
        player_2_data), "taille differente des donnees d'entrée"
    stats = {**{f"{index}_{entete}_player_1": p1_datum for (entete, p1_datum) in zip(entetes, player_1_data)},
             **{f"{index}_{entete}_player_2": p1_datum for (entete, p1_datum) in zip(entetes, player_2_data)}}
    return stats


def sorted_dict(data):
    """
    sort the key of a dictionary and return
    another one
    """
    keys = sorted(data.keys())
    values = [data[key_] for key_ in keys]
    data_return = {key: value for (key, value) in zip(keys, values)}
    return data_return


def match_data(index, tree):
    """
    getting the stats for the player
    inex : categorie set1, 2, match ?
    tree : html element
    """
    data = dict()
    to_store = tree.xpath(
        f".//div[@class='mc-stats__tab js-stats-tab is-active' and @data-tab-key='{index}']/div[contains(@class, 'mc-stats__stats-container')]")
    for match_cat in to_store:
        # print(f"index {to_store.index(match_cat)}")
        entetes = match_cat.xpath(".//p[@class='mc-stats__stat-label']//text()")
        player_1_data = [elt for elt in match_cat.xpath(
            ".//div[@class='mc-stats__stat-player-container mc-stats__stat-player-container--player-a']//text()") if
                         len(elt.strip()) > 0 and "%" not in elt]
        player_2_data = [elt for elt in match_cat.xpath(
            ".//div[@class='mc-stats__stat-player-container mc-stats__stat-player-container--player-b']//text()") if
                         len(elt.strip()) > 0 and "%" not in elt]
        data = {**data, **match_statistics(index, entetes, player_1_data, player_2_data)}

    return sorted_dict(data)

def substring_before(s, delimiter):
    return s.split(delimiter)[0]

def substring_after(s, delimiter):
    return s.split(delimiter)[1]

@timer
def retrieving_match_data(match_url):
    driver = webdriver.Firefox(options=options, executable_path=executable_path)
    driver.set_page_load_timeout(60)
    driver.get(match_url)
    time.sleep(2)
    # Find the match details
    h2h = "Head to Head"
    # match_stat = "SAP Match Stats"
    # Find the SAP Match stat button
    try:
        tab_ = driver.find_element(By.XPATH, "//li[@role='tab' and text()='SAP Match Stats']")
        tab_.click()
    except Exception as e:
        print(f"impossible d'obtenir plus de stats sur le match")
        driver.close()

    try:
        # click on the match   
        match_ = driver.find_element(By.XPATH, f"//li[contains(@class, 'js-tab-item js-match') and text()='Match']")
        match_.click()

        tree = html.fromstring(driver.page_source)

        data_match = match_data("match", tree)

        sets_details = driver.find_elements(By.XPATH, f"//li[contains(@class, 'js-tab-item js-set')]")
        for set_ in sets_details:
            set_.click()
            time.sleep(1)
            index = f"set{sets_details.index(set_) + 1}"
            # print(f"index:{index}")
            tree = html.fromstring(driver.page_source)
            data_match = {**data_match, **match_data(index, tree)}
    except Exception as e:
        print(f"impossible d'obtenir plus de stats sur le match")
        data_match = {}
        driver.close()
        
    try:
        ### traiter le dernier pan d'element
        items = ["h2h_wins",  "Height", "Date of Birth", "Plays"]
        data_list = []
        # Find the match details
        h2h = "Head to Head"
        # match_stat = "SAP Match Stats"
        # Find the SAP Match stat button

        tab_ = driver.find_element(By.XPATH, "//li[@role='tab' and text()='Head to Head']")
        tab_.click()
        time.sleep(1)
        tree = html.fromstring(driver.page_source)

        h2h_wins = tree.xpath("""
                                .//div[@class='mc-tabs__tab js-tab is-active' and @data-ui-tab='Head to Head']
                                //div[@class='player-h2h__vs']
                                //span[@class='player-h2h__matches-number' and contains(@data-content, 'Win')]
                                /text()
                              """
                              )

        heights = tree.xpath("""
                          .//div[@class='mc-stats__stat-container ' 
                            and .//p[@class='mc-stats__stat-label'
                            and text()='Height']]//text()[contains(., '(') and contains(., ')') or contains(., 'N/A')]
                       """)
        heights = [substring_before(substring_after(h, '('), ')') if 'm' in h else h for h in heights ]
        heights = [extract_height(elt) for elt in heights]
        if len(heights)==1:
            heights = heights + heights
        #print(f"extracted {heights}")

        data_list.append(h2h_wins)
        data_list.append(heights)
        for item in items[2:]:

            data = [elt.strip() for elt in tree.xpath(f""".//div[@class='mc-stats__stat-container ' 
                                                      and .//p[@class='mc-stats__stat-label'
                                                      and text()='{item}']]//text()""")
                    if len(elt.strip()) > 0 and elt != item
                    ]

            if item=="Date of Birth":
                data = list(map(birthday, data))
            #dict_function = {"Date of Birth": birthday, "Height": extract_height}
            #data = list(map(birthday, data))
            data_list.append(data)
        #print(f"items : {items}")
        #print(f"data_list: {data_list}")
        players_info_stat = players_info(items, *data_list)
        driver.quit()
        return {**data_match, **players_info_stat} | {"url_match_stats": match_url}
    except Exception as e:
        driver.quit()

