import pandas as pd
import os
from matches.match import *
from matches.match_details import *
from utilities.utilities import *

# verifiy if the PRD-TRD folder exist for the given year, otherwise, create it (problem with 30)
def generate_tournament_matches(logger, path_of_tourney):
    """
    based on the tournament url, generate csv
    with matches played with basic stats as scores
    and time
    Args
    --------------
    tourney_path : the path to the tournament csv in
    the folders
    Outputs
    ------------
    the file generate in the folder given in input
    """
    container = "prd-trd"
    level = "0_raw"
    #print(f"im in the function input: {path_of_tourney}")
    tourney_name = path_of_tourney.split("\\")[-1]
    tournament_path = os.path.join(path_of_tourney, f"{tourney_name}.csv")
    #print(f"im in the function tournament path name: {tournament_path}")
    #print(f" tourney name: {tourney_name}")
    tournament = pd.read_csv(tournament_path, sep=";")
    size = len(tournament)
    year = path_of_tourney.split("\\")[-2]
    print(f"year: {year}")

    #get the list of the tourney based on tournaments_for_year
    for index, tourney in tournament.iterrows():
        print(f" donnees de tournoi brut: {len(tournament)}")
        print(f" donnees de tournoi deduplicated: {len(tournament.drop_duplicates())}")
        if index>=0:
            logger.log_info(f"processing tourney {index}/{size} {tourney['title']} for year {year}")
            data_tournament_values = retrieve_matches_html_robust(tourney['scores_link'])
            data_tournament = data_tournament_values[1]
            elapsed_time = data_tournament_values[0]
            logger.log_info(f"executing retrieving tournament {tourney['title']} matches  took {elapsed_time: .1f}s")
            #store the data
            os.makedirs(path_of_tourney, exist_ok=True)
            logger.log_info(f"tourney data will be stored here {path_of_tourney}")                                
            
            
            print(f"tourney link: {tourney['scores_link']}")
            data_tournament["scores_link"] = tourney['scores_link']
            if len(data_tournament)>2:
                #taking the matches of the tournament
                logger.log_info(f"data tournaments data will be stored here {path_of_tourney}")
                data_tournament.to_csv(os.path.join(path_of_tourney, "matches.csv"), sep=";", index=False)

def generate_tournament_matches_details(logger, tourney_path):
    """
    based on the matches csv, generate csv
    with matches details 
    Args
    --------------
    tourney_path : the path to the csv folder of
    the tournament
    Outputs
    ------------
    the file generate in the folder given in input
    """
    # une autre boucle
    data_tournament_details = []
    tourney_time = 0
    tourney_name = tourney_path.split("\\")[-1]
    year = tourney_path.split("\\")[-2]
    mach_path = os.path.join(tourney_path, "matches.csv")
    data_tournament = pd.read_csv(mach_path, sep=";")
    print(f" donnees de match brut: {len(data_tournament)}")
    print(f" donnees de match deduplicated: {len(data_tournament.drop_duplicates())}")
    for index_match, match in data_tournament.drop_duplicates().iterrows():
        try:
            match_details_value = retrieving_match_data(match["url_match_stats"])
            match_details = match_details_value[1]
            elapsed_time = match_details_value[0]
            tourney_time += round(elapsed_time, 1)
            logger.log_info(f" elapsed time: {elapsed_time: .1f}s year: {year} tourney: {tourney_name} index: {index_match}/{len(data_tournament.drop_duplicates())}, stage: {match['stage']}")
        except Exception as e:
            logger.log_info(f"error treating line {index_match}/{len(data_tournament.drop_duplicates())}, {tourney_name}, url {match['url_match_stats']}")
        data_tournament_details.append(match_details)
        time.sleep(5)
    data_tournament_details_safe = [elt for elt in data_tournament_details if isinstance(elt, dict)]
    data_tournament_skipped = [elt for elt in data_tournament_details if not isinstance(elt, dict)]
    logger.log_info(f"retrieve all matches from {tourney_name} in {tourney_time: .1f}s")
    logger.log_info(f"matchs skipped for tourney {tourney_name}:{len(data_tournament_skipped)}")
    data_tournament_details_pd = pd.DataFrame(data_tournament_details_safe)
    #write to csv
    if len(data_tournament_details_pd)>2:
        #taking the matches of the tournament
        logger.log_info(f"data tournaments data will be stored here {tourney_path}")
        data_tournament_details_pd.to_csv(os.path.join(tourney_path,"matches_details.csv"), sep=";", index=False)
    time.sleep(60)